<?php

 include("header.php"); 
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <style>
        .body{
            background-color: #a88788;
        }
    </style>
</head>
<body class="body">



    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-6">
                <form action="manage_cart.php" method="POST">
                    <div class="card mt-5">
                        <img src="Image/food 1.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title ">Chese Cake</h5>
                            <p class="card-text">Price: ks,5000</p>
                            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Card</button>
                            <input type="hidden" name="Item_Name" value="Chese Cake">
                            <input type="hidden" name="Price" value="5000">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6">
                <form action="manage_cart.php" method="POST">
                    <div class="card mt-5">
                        <img src="Image/food 2.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title ">Fish</h5>
                            <p class="card-text">Price: ks,7000</p>
                            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Card</button>
                            <input type="hidden" name="Item_Name" value="Fish">
                            <input type="hidden" name="Price" value="7000">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6">
                <form action="manage_cart.php" method="POST">
                    <div class="card mt-5">
                        <img src="Image/food 3.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title ">Barkar</h5>
                            <p class="card-text">Price: ks,3500</p>
                            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Card</button>
                            <input type="hidden" name="Item_Name" value="Barkar">
                            <input type="hidden" name="Price" value="3500">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6">
                <form action="manage_cart.php" method="POST">
                    <div class="card mt-5">
                        <img src="Image/food 4.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title ">Beef</h5>
                            <p class="card-text">Price: ks,10000</p>
                            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Card</button>
                            <input type="hidden" name="Item_Name" value="Beef">
                            <input type="hidden" name="Price" value="10000">
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php
                $select_products=mysqli_query($con,"SELECT * FROM `addedproduct`");
                if(mysqli_num_rows($select_products) > 0)
                {
                    while($row=mysqli_fetch_assoc($select_products))
                    {                    
            ?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <form action="manage_cart.php" method="POST">
                    <div class="card mt-5">
                        <img src="Admin/uploaded_img/<?php echo $row['image']; ?>" alt="" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title text-capitalize"><?php echo $row['name'];?></h5>
                            <p class="card-text">Price: ks,<?php echo $row['price'];?></p>
                            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Card</button>
                            <input type="hidden" name="Item_Name" value="<?php echo $row['name'];?>">
                            <input type="hidden" name="Price" value="<?php echo $row['price'];?>">
                        </div>
                    </div>
                </form>
            </div>
            <?php
              };
            };
            ?>
        </div>
    </div>
    <?php
    include 'footer.php';
    ?>
</body>
</html>