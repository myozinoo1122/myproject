-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2023 at 06:22 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `addedproduct`
--

CREATE TABLE `addedproduct` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addedproduct`
--

INSERT INTO `addedproduct` (`id`, `name`, `price`, `image`) VALUES
(100, 'kkk', '888', 'brett-jordan-8xt8-HIFqc8-unsplash.jpg'),
(104, 'kkk', '888', 'brett-jordan-8xt8-HIFqc8-unsplash.jpg'),
(105, 'kkk', '888', 'brett-jordan-8xt8-HIFqc8-unsplash.jpg'),
(107, 'kkk', '888', 'brett-jordan-8xt8-HIFqc8-unsplash.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `Admin_Name` varchar(100) NOT NULL,
  `Admin_Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`Admin_Name`, `Admin_Password`) VALUES
('TJ WEBDEV', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `reply` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `phone`, `reply`) VALUES
(3, 'mzo', 'mzo@gmail.com', '09755150379', 'hi'),
(4, 'mzo', 'mzo@gmail.com0', '09755150379', 'hi'),
(5, 'mzo', 'mzo@gmail.com0', '09755150379', 'hi'),
(6, 'mzo', 'mzo@gmail.com', '098', ''),
(7, 'mzo', 'mzo@gmail.com', '0976', 'qqq'),
(8, 'mzo', 'mzo@gmail.com', '0976', 'qqq');

-- --------------------------------------------------------

--
-- Table structure for table `order_manager`
--

CREATE TABLE `order_manager` (
  `Order_id` int(100) NOT NULL,
  `Full_Name` text NOT NULL,
  `Phone_No` bigint(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Pay_Mode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_manager`
--

INSERT INTO `order_manager` (`Order_id`, `Full_Name`, `Phone_No`, `Address`, `Pay_Mode`) VALUES
(53, 'myo', 4554, 'sef', 'COD'),
(54, 'myo', 938293, 'shwebo', 'COD'),
(55, 'myo', 434, 'shwebi', 'COD'),
(56, 'myo', 8787, 'dds', 'COD'),
(57, 'myo', 3435, 'dd', 'COD'),
(58, 'myo', 6677878789, 'vjvb', 'COD');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`) VALUES
(2, 'mzo1', 'mzo1@gmail.com', '123'),
(3, 'myo', 'myo@gmail.com', '123'),
(4, 'aung myo', 'aung@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `user_orders`
--

CREATE TABLE `user_orders` (
  `Order_Id` int(100) NOT NULL,
  `Item_Name` varchar(100) NOT NULL,
  `Price` int(100) NOT NULL,
  `Quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_orders`
--

INSERT INTO `user_orders` (`Order_Id`, `Item_Name`, `Price`, `Quantity`) VALUES
(27, 'Chese Cake', 5000, 1),
(27, 'Chese Cake', 5000, 1),
(28, 'Chese Cake', 5000, 1),
(29, 'Chese Cake', 5000, 1),
(29, 'Fish', 7000, 1),
(30, 'Chese Cake', 5000, 1),
(30, 'Fish', 7000, 1),
(31, 'Chese Cake', 5000, 1),
(32, 'Chese Cake', 5000, 1),
(32, 'Fish', 7000, 1),
(33, 'Chese Cake', 5000, 1),
(34, 'Chese Cake', 5000, 1),
(34, 'Fish', 7000, 2),
(34, 'Barkar', 3500, 3),
(34, 'Beef', 10000, 4),
(35, 'Chese Cake', 5000, 1),
(36, 'Beef', 10000, 1),
(37, 'Barkar', 3500, 3),
(37, 'Beef', 10000, 1),
(38, 'Beef', 10000, 1),
(39, 'Beef', 10000, 1),
(40, 'Barkar', 3500, 4),
(41, 'Barkar', 3500, 1),
(42, 'tea', 12, 1),
(42, 'myo', 12, 1),
(42, 'aaa', 300, 1),
(43, 'kkk', 888, 1),
(44, 'Fish', 7000, 1),
(45, 'Fish', 7000, 2),
(46, 'kkk', 888, 1),
(47, 'Chese Cake', 5000, 1),
(48, 'Barkar', 3500, 1),
(49, 'Fish', 7000, 10),
(50, 'Fish', 7000, 1),
(51, 'Fish', 7000, 1),
(52, 'Barkar', 3500, 1),
(53, 'Chese Cake', 5000, 1),
(54, 'Fish', 7000, 2),
(55, 'Chese Cake', 5000, 1),
(56, 'Fish', 7000, 1),
(56, 'Fish', 7000, 1),
(56, 'Fish', 7000, 1),
(56, 'Barkar', 3500, 1),
(56, 'Barkar', 3500, 1),
(56, 'Beef', 10000, 1),
(57, 'kkk', 888, 5),
(58, 'Chese Cake', 5000, 2),
(58, 'Fish', 7000, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addedproduct`
--
ALTER TABLE `addedproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_manager`
--
ALTER TABLE `order_manager`
  ADD PRIMARY KEY (`Order_id`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addedproduct`
--
ALTER TABLE `addedproduct`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_manager`
--
ALTER TABLE `order_manager`
  MODIFY `Order_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
