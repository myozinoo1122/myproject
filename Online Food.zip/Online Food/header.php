<?php
include 'Connection.php';
session_start();
if(!isset($_SESSION['user-id']))
{
  header("location:login.php");
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- icon link -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.3/font/bootstrap-icons.min.css"
      integrity="sha512-YFENbnqHbCRmJt5d+9lHimyEMt8LKSNTMLSaHjvsclnZGICeY/0KYEeiHwD1Ux4Tcao0h60tdcMv+0GljvWyHg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <title>header</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark text-light fs-5 fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand fs-3 text-capitalize fw-bolder px-5" href="#">HELLO -  <?php echo $_SESSION['user-id'] ?> </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse p-2" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home.php"><i class="bi bi-house-heart"></i> Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link " href="index.php"><i class="bi bi-database-add"></i>  Product</a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="about.php"><i class="bi bi-calendar2-heart"></i> About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="feedback.php"><i class="bi bi-chat-dots"></i> Fedback</a>
          </li>
      </ul>
      <div class="pt-2">
            <?php 
                $count=0;
                if(isset($_SESSION['cart']))
                {
                $count=count($_SESSION['cart']);
                }
            ?>
            <a href="mycart.php" class="btn btn-success me-3"><i class="bi bi-cart3"></i> My Cart (<?php echo $count ; ?>)</a>
     </div>
     <div class="pt-2">
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
            <button type="submit" name="Logout" class="btn btn-success me-3"><i class="bi bi-box-arrow-right"></i>  LOG OUT</button>
        </form>
     </div>
    </div>
  </div>
</nav>
<?php
if(isset($_POST["Logout"]))
{
    session_destroy();
    header("location: login.php") ;
}
?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>