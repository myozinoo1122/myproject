<?php
include("header.php"); 
//  error_reporting(1);
require("Connection.php");
session_start();
if(!isset($_SESSION['AdminLoginId']))
{
    header("location: Admin_Login.php");
}
if(isset($_POST["Logout"]))
{
    session_destroy();
    header("location: Admin_Login.php") ;
    
}
if(isset($_POST['add_product']))
{
    $p_name=$_POST['p-name'];    
    $p_price=$_POST['p-price'];    
    $p_image=$_FILES['p-image']['name'];    
    $p_image_tmp_name=$_FILES['p-image']['tmp_name'];
    $p_image_folder='uploaded_img/'.$p_image;
    
    $insert_query = mysqli_query($con,"INSERT INTO `addedproduct`(name,price,image) VALUES ('$p_name','$p_price','$p_image')") or die('query failed');

    if($insert_query)
    {
        move_uploaded_file($p_image_tmp_name,$p_image_folder);
        echo"<script>alert('product add succesfully');</script>";
    }
    else
    {
        echo"<script>alert('could not add the product');</script>";
    }

};
if(isset($_GET['delete']))
{
    $delete_id = $_GET['delete'];
    $delete_query = mysqli_query($con,"DELETE FROM `addedproduct` WHERE id =$delete_id");
    if($delete_query)
    {
        header('location: index.php');
        echo"<script>alert('product has been deleted');</script>";
    }
    else
    {
        header('location: index.php');
        echo"<script>alert('product could not be deleted');</script>";
    };
};
if(isset($_POST['update_product']))
{
    $update_p_id=$_POST['update_p_id'];    
    $update_p_name=$_POST['update_p_name'];    
    $update_p_price=$_POST['update_p_price'];    
    $update_p_image=$_FILES['update_p_image']['name'];    
    $update_p_image_tmp_name=$_FILES['update_p_image']['tmp_name'];    
    $update_p_image_folder='uploaded_img/'.$update_p_image;
    
    $update_query=mysqli_query($con,"UPDATE `addedproduct`SET name='$update_p_name',price='$update_p_price',image='$update_p_image' WHERE id='$update_p_id'");

    if($update_query)
    {
        move_uploaded_file($update_p_image_tmp_name,$update_p_image_folder);
        echo"<script>alert('product update succesfully');</script>";
        header('location:index.php');
    }
    else
    {
        echo"<script>alert('product could not be updated');</script>";
        header('location:index.php');
    }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- icon link -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.3/font/bootstrap-icons.min.css"
      integrity="sha512-YFENbnqHbCRmJt5d+9lHimyEMt8LKSNTMLSaHjvsclnZGICeY/0KYEeiHwD1Ux4Tcao0h60tdcMv+0GljvWyHg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />

    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,900&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,900&display=swap" rel="stylesheet">
    <title>header</title>
    <style>
        body{
            margin:0;
            font-family: 'Poppins', sans-serif;
            background-color:#a88788;
        }
        .container-fluid{
            color: #f0f0f0;
            font-family: 'Poppins', sans-serif;
            display:flex;
            flex-direction:row;
            align-items:center;
            justify-content:space-between;
            padding:0 60px;
            background-color: #1c1c1e;
        }
        .logout form button{
            width:120px;
            height:50px;
            border-radius:5px;
        }
        html{
            overflow-x:hidden;
        }
        .container{
            max-width: 1200px;
            margin:0 auto;
        }
        section{
            padding: 2rem;
        }
        .add-product-form{
            max-width: 50rem;
            background-color: #e8edf2;
            border-radius:.5rem;
            padding:2rem;
            margin:0 auto;
            margin-top:2rem;
        }
        .add-product-form h3{
            font-size:2.5rem;
            margin-bottom:1rem;
            color:black;
            text-transform:capitalize;
            text-align:center;
        }
        .add-product-form .box{
            text-transform:none;
            padding:1rem 1.2rem;
            font-size:1.2rem;
            color:black;
            border-radius:.5rem;
            background-color:white;
            margin:1rem 0;
            width: 100%;
        }
        .btn,
        .option-btn,
        .delete-btn{
            display:block;
            width: 100%;
            text-align:center;
            background-color:blue;
            color:white;
            font-size:1.2rem;
            padding:1rem 3rem;
            border-radius:.5rem;
            cursor:pointer;
            text-decoration:none;
            margin:10px 0 10px 0;
        }
        .option-btn i,
        .delete-btn i{
            padding-right:10px;
        }
        .btn:hover,
        .option-btn:hover,
        .delete-btn:hover{
            background-color:black;
            color:darkred;
        }
        .option-btn{
            background-color:orange;
        }
        .delete-btn{
            margin-top:10px;
            background-color:red;

        }
        .display-product-table table{
            width: 100%;
            text-align:center;
            text-transform:capitalize;
        }
        .display-product-table table thead th{
            padding:1.5rem;
            font-size:2rem;
            background-color:black;
            color:white;
            
        }
        .display-product-table table td{
            padding:1.5rem;
            font-size:2rem;
        }
        .display-product-table table td:first-child{
            padding:0;
        }
        .display-product-table table tr:nth-child(even){
            background-color:#e8edf2;
        }
        .display-product-table .empty{
            margin-bottom:2rem;
            text-align:center;
            background-color:#e8edf2;
            color:black;
            font-size:2rem;
            padding:1.5rem;
            text-transform:capitalize;
        }
        .edit-form-container{
            position:fixed;
            top:100px;left:0;
            z-index: 1100;
            /* background-color:#a88788; */
            padding:2rem;
            display:none;
            align-items:center;
            justify-content:center;
            max-height:90vh;
            width:100%;
        }
        .edit-form-container form{
            width:50rem;
            border-radius:0.5rem;
            background-color:#e8edf2;
            text-align:center;
            padding:2rem;
        }
        .edit-form-container form .box{
            width:100%;
            background-color:white;
            border-radius:0.5rem;
            margin:1rem 0;
            font-size:1.7rem;
            color:black;
            padding:1rem 1.2rem;
            text-transform:none;
        }
    </style>
  </head>
  <body>
   
    <div class="container mt-5">
        <section>
            <form action="" method="post" class="add-product-form" enctype="multipart/form-data">
                <h3>add a new product</h3>
                <input type="text" name="p-name" placeholder="enter the product name" class="box" required>
                <input type="number" name="p-price" min="0" placeholder="enter the product price" class="box" required>
                <input type="file" name="p-image" min="0" accept="image/png, image/jpg, image/jpeg" class="box" required>
                <input type="submit" value="add the product" name="add_product" class="btn">
            </form>
        </section>
        <section class="display-product-table">
            <table>
                <thead>                  
                        <th>product image</th>
                        <th>product name</th>
                        <th>product price</th>
                        <th>action</th>
                </thead>

                <tbody>
                    <?php
                    
                    $select_products=mysqli_query($con,"SELECT * FROM `addedproduct`");
                    if(mysqli_num_rows($select_products) > 0)
                    {
                        while($row=mysqli_fetch_assoc($select_products))
                        {                        
                    ?>

                    <tr>
                        <td><img src="uploaded_img/<?php echo $row['image']; ?>" height="100" alt=""></td>
                        <td><?php echo $row['name']; ?></td>
                        <td>ks,<?php echo $row['price']; ?></td>
                        <td>
                            <a href="index.php?delete=<?php echo $row['id'];?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this?');"><i class="bi bi-trash3"></i>  Delete</a>
                            <a href="index.php?edit=<?php echo $row['id'];?>" class="option-btn"><i class="bi bi-pencil-square"></i>    Update</a>
                        </td>
                    </tr>

                    <?php
                        };
                    }
                        else
                        {
                           echo"<div class='empty'>no product added</div>"; 
                        }
                    

                    ?>
                </tbody>
            </table>
        </section>
        <section class="edit-form-container">
           <?php
                if(isset($_GET['edit']));
                $edit_id=$_GET['edit'];
                $edit_query=mysqli_query($con,"SELECT * FROM `addedproduct` WHERE id=$edit_id");
                if(mysqli_num_rows($edit_query) > 0)
                {
                    while($fetch_edit = mysqli_fetch_assoc($edit_query))
                    {
           ?>
           <form action="" method="post" enctype="multipart/form-data">
            <img src="uploaded_img/<?php echo $fetch_edit['image']; ?>" height="200" alt="">
            <input type="hidden" name="update_p_id" value="<?php echo $fetch_edit['id']; ?>">
            <input type="text" class="box" required name="update_p_name" value="<?php echo $fetch_edit['name']; ?>">
            <input type="number" min="0" class="box" required name="update_p_price" value="<?php echo $fetch_edit['price']; ?>">
            <input type="file" class="box" required name="update_p_image" accept="image/jpg,image/png,image/jpeg">
            <input type="submit" value="Update The Product" name="update_product" class="btn">
            <input type="reset" value="Cancel" id="close-edit" class="option-btn">
           </form>
           <?php
           
                    };
                    echo"<script>document.querySelector('.edit-form-container').style.display = 'flex'</script>";  
                };
                
           ?>
        </section>
    </div>
    

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
    <script>
        document.querySelector('#close-edit').onclick = () => {
        document.querySelector('.edit-form-container').style.display = 'none';
        window.location.href = 'index.php';
        }

    </script>
  </body>
</html>