<?php
require("Connection.php");
session_start();
if(!isset($_SESSION['AdminLoginId']))
{
    header("location: Admin_Login.php");
}
if(isset($_POST["Logout"]))
{
    header("location: Admin_Login.php") ;
    session_destroy();
}
if(isset($_GET['delete']))
{
    $delete_id = $_GET['delete'];
    $delete_query = mysqli_query($con,"DELETE FROM `user_form` WHERE id =$delete_id");
    if($delete_query)
    {
        header('location: userform.php');
        echo"<script>alert('product has been deleted');</script>";
    }
    else
    {
        header('location: userform.php');
        echo"<script>alert('product could not be deleted');</script>";
    };
};
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- icon link -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.3/font/bootstrap-icons.min.css"
      integrity="sha512-YFENbnqHbCRmJt5d+9lHimyEMt8LKSNTMLSaHjvsclnZGICeY/0KYEeiHwD1Ux4Tcao0h60tdcMv+0GljvWyHg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />

    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,900&display=swap" rel="stylesheet">
    <title>header</title>
    <style>
        body{
            margin:0;
            font-family: 'Poppins', sans-serif;
            background-color:#a88788;
        }
        .container-fluid{
            color: #f0f0f0;
            font-family: 'Poppins', sans-serif;
            display:flex;
            flex-direction:row;
            align-items:center;
            justify-content:space-between;
            padding:0 60px;
            background-color: #1c1c1e;
        }
        .logout form button{
            width:120px;
            height:50px;
            border-radius:5px;
        }
        .delete-btn{
            display:block;
            width: 100%;
            text-align:center;
            background: rgb(255,0,189);
	        background: radial-gradient(circle, rgba(255,0,189,1) 0%, rgba(0,0,0,1) 100%);
            color:white;
            font-size:1.2rem;
            padding:1rem 3rem;
            border-radius:.5rem;
            cursor:pointer;
            text-decoration:none;
            /* margin:10px 0 10px 0; */
        }
        .delete-btn i{
            padding-right:10px;
        }
        .delete-btn:hover{
            background-color:black;
            color:darkred;
        }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark text-light fs-5 ">
        <div class="container-fluid mb-5 fixed-top ">
            <h1 class="me-3">ADMIN PANEL-<?php echo $_SESSION['AdminLoginId'] ?></h1>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
            <div class="collapse navbar-collapse p-2" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                    <li class="nav-item">
                        <a class="nav-link text-light" href="Admin_Panel.php"><i class="bi bi-eye me-1 text-light"></i>Order View</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="index.php"><i class="bi bi-database-add me-1 text-light"></i>Added Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="view_product.php"><i class="bi bi-cpu me-1 text-light"></i>View Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="Feedback.php"><i class="bi bi-chat-left-dots me-1 text-ligh"></i>Feedback</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="userform.php"><i class="bi bi-people-fill me-1 text-ligh"></i>User</a>
                    </li>
                </ul>
                <div class="pt-2 logout ">
                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
                        <button type="submit" name="Logout">LOG OUT</button>
                    </form>
                </div>
            </div>
        </div>
    </nav>
    <div class="pt-5">
        <div class="container mt-5">
            <div class="row ">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <table class="table text-center table-dark table-responsive">
                    <thead>
                        <tr>
                        <th scope="col">Customer ID</th>
                        <th scope="col">Customer Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Passward</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                        <?php
                            $select_feedback=mysqli_query($con,"SELECT * FROM `user_form`");
                            if(mysqli_num_rows($select_feedback) > 0)
                            {
                            while($row=mysqli_fetch_assoc($select_feedback))
                                {
                        ?>
                        <tr>
                            <th><?php echo $row['id'];?></th>
                            <td><?php echo $row['name'];?></td>
                            <td><?php echo $row['email'];?></td>
                            <td><?php echo $row['password'];?></td>
                            <td>
                                <a href="userform.php?delete=<?php echo $row['id'];?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this?');"><i class="bi bi-trash3"></i>  Delete</a>
                            </td>
                            <?php
                                    };
                            };    
                            ?>
                        </tr>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>