<!DOCTYPE html>
<?php 
    require("Connection.php")
 ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- icon link -->
    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.3/font/bootstrap-icons.min.css"
    integrity="sha512-YFENbnqHbCRmJt5d+9lHimyEMt8LKSNTMLSaHjvsclnZGICeY/0KYEeiHwD1Ux4Tcao0h60tdcMv+0GljvWyHg=="
    crossorigin="anonymous"
    referrerpolicy="no-referrer"
    />

    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,900&display=swap" rel="stylesheet">
    <title>Admin Login Panel</title>
    <style>
        body{
            background-color:#a88788;
        }
    </style>
</head>
<body>
    <div class="container col-12">
        <div class="myform col-8">
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'] ) ?>">
                <h2>ADMIN LOGIN</h2>
                <input type="text" placeholder="Admin Name" name="AdminName">
                <input type="password" placeholder="Password" name="AdminPass">
                <button type="submit" name="Login">LOGIN</button>
            </form>
        </div>
        <div class="image img-fluid col-4">
            <img src="Image/gilles-lambert-S_LhjpfIdm4-unsplash.jpg">
        </div>
    </div>

<?php

function input_filter($data)
{
    $data=trim($data);
    $data=stripcslashes($data);
    $data=htmlspecialchars($data);
    return $data;
}

if(isset($_POST['Login']))
{
    #filtering user input
    $AdminName=input_filter($_POST['AdminName']);
    $AdminPass=input_filter($_POST['AdminPass']);

    #escaping special symbols used in SQL statement
    $AdminName=mysqli_real_escape_string($con,$AdminName);
    $AdminPass=mysqli_real_escape_string($con,$AdminPass);

    #query template 

    $query="SELECT * FROM `admin_login` WHERE `Admin_Name`=? AND `Admin_Password`=?";

    #prepared statement
    if($stmt=mysqli_prepare($con,$query))
    {
        mysqli_stmt_bind_param($stmt,"ss",$AdminName,$AdminPass); //binding value to template or prepare statement
        mysqli_stmt_execute($stmt); //executing prepared statement
        mysqli_stmt_store_result($stmt); //transfering the result of execution in $strmt
        if(mysqli_stmt_num_rows($stmt)==1)
        {
            session_start();
            $_SESSION['AdminLoginId']=$AdminName;
            header("location: Admin_Panel.php");
        }
        else
        {
            echo"<script>alert('Invalid Admin Name or Password');</script>";
        }
        mysqli_stmt_close($stmt);
    }
    else
    {
        echo"<script>alert('SQL Query cannot be prepared');</script>";
    }

}

?>

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>