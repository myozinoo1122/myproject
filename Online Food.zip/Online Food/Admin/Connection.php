<?php

    $con=mysqli_connect("localhost","myozinoo1122","09971276331","testing");

    if(mysqli_connect_error()){
        echo"Cannot connect to database";
        exit();
    }
   
?>