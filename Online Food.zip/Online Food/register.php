<?php
include 'Connection.php';

if(isset($_POST['submit']))
{
    $name=mysqli_real_escape_string($con,$_POST['name']);
    $email=mysqli_real_escape_string($con,$_POST['email']);
    $pass=mysqli_real_escape_string($con,$_POST['password']);
    $cpass=mysqli_real_escape_string($con,$_POST['cpassword']);
    
    $select=" SELECT * FROM `user_form` WHERE email = '$email' && password = '$pass'";
    
    $result=mysqli_query($con,$select);

    if(mysqli_num_rows($result)>0)
    {
        // $message[]='user already exist!';
        echo"<script>alert('user already exist!');</script>";
    }
    else
    {
        if($pass !=$cpass)
        {
        //    $message[]='password not matched!';  
           echo"<script>alert('password not matched!');</script>";
        }
        else
        {
            $insert="INSERT INTO user_form(name,email,password) VALUES('$name','$email','$pass')";
            mysqli_query($con,$insert);
            header('location:login.php');
        }
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="form-container">
        <form action="" method="post" enctype="multipart/form-data">
            <h3>register now</h3>
            <input type="text" name="name" placeholder="enter username" class="box" required>
            <input type="email" name="email" placeholder="enter email" class="box" required>
            <input type="password" name="password" placeholder="enter password" class="box" required>
            <input type="password" name="cpassword" placeholder="confirm password" class="box" required>
            <input type="submit" name="submit" value="Register now" class="btn">
            <p>already have an account ? <a href="login.php">login now</a></p>
        </form>
    </div>
</body>
</html>