<?php
session_start();
include 'Connection.php';

if(isset($_POST['submit']))
{
    $email=mysqli_real_escape_string($con,$_POST['email']);
    $pass=mysqli_real_escape_string($con,$_POST['password']);
    
    $select=" SELECT * FROM `user_form` WHERE email = '$email' && password = '$pass'";
    
    $result=mysqli_query($con,$select);

    if(mysqli_num_rows($result)>0)
    {
        $row=mysqli_fetch_assoc($result);
        $_SESSION['user-id']=$row['name'];
        header('location:home.php');
    }
    else
    {
        echo"<script>alert('incorrect email or password!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="form-container">
        <form action="" method="post" enctype="multipart/form-data">
            <h3>login now</h3>
            <input type="email" name="email" placeholder="enter email" class="box" required>
            <input type="password" name="password" placeholder="enter password" class="box" required>
            <input type="submit" name="submit" value="Login now" class="btn">
            <p>don't have an account ? <a href="register.php">register now</a></p>
        </form>
    </div>
</body>
</html>