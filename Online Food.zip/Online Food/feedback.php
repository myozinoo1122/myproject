<?php
 include("header.php"); 
 if(isset($_POST['submit']))
 {
  $name=mysqli_real_escape_string($con,$_POST['name']);
  $email=mysqli_real_escape_string($con,$_POST['email']);
  $phone=mysqli_real_escape_string($con,$_POST['phone']);
  $reply=mysqli_real_escape_string($con,$_POST['reply']);

  $select=" SELECT * FROM `feedback` WHERE email = '$email'";

  $result=mysqli_query($con,$select);
  if (!$name) 
  {
    echo"<script>alert('Your name is required!');</script>";
  }
  if (!$phone) 
  {
      echo"<script>alert('Your phone is required!');</script>";
  }
  if (!$email) 
  {
      echo"<script>alert('Your email is required!');</script>";
  }
  if ($useremail && $useremail !== $email) 
  {
      echo"<script>alert('You can't use different email while logged in.!');</script>";
  }
  else
  {
      $insert="INSERT INTO feedback(name,email,phone,reply) VALUES('$name','$email','$phone','$reply')";
      mysqli_query($con,$insert);
  }
 }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- icon link -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.3/font/bootstrap-icons.min.css"
      integrity="sha512-YFENbnqHbCRmJt5d+9lHimyEMt8LKSNTMLSaHjvsclnZGICeY/0KYEeiHwD1Ux4Tcao0h60tdcMv+0GljvWyHg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <style>
      body{
        background-color:#a88788;
      }
      .container{
        min-height: 100vh;
        background-color: #a88788;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        width: 100%;
      }
      .container form{
        padding: 20px;
        background: rgb(255,0,189);
	      background: radial-gradient(circle, rgba(255,0,189,1) 0%, rgba(0,0,0,1) 100%);
        box-shadow: 5px 10px #5d3d3d;
        text-align: center;
        width: 500px;
        border-radius: 5px;
        margin-top:150px;
      }
      .container form h2{
        margin-bottom: 10px;
        font-size: 30px;
        color: white;
        text-transform: capitalize;
        font-family: Georgia, serif;
      }
      .container form .box{
        width: 100%;
        border-radius: 5px;
        padding: 12px 2px;
        font-size: 18px;
        color: dark;
        margin: 10px 2px;
        background-color: #915f99;
        text-transform: capitalize;
        font-family: Georgia, serif;
      }
      #reply{
        width: 100%;
        border-radius: 5px;
        padding: 12px 2px;
        font-size: 18px;
        color: dark;
        margin: 10px 2px;
        background-color: #915f99;
        text-transform: capitalize;
        font-family: Georgia, serif;
      }
      .btn-sub{
        width: 100%;
        border-radius: 5px;
        padding: 10px 30px;
        color: white;
        display: block;
        text-align: center;
        cursor: pointer;
        font-size: 20px;
        margin-top: 10px;
        font-family: Georgia, serif;
        background-color: darkred;
      }
      .btn-sub:hover{
        background-color: darkblue;
      }
    </style>
    <title>feedback</title>
  </head>
  <body>
    <div class="container">
      <div class="row">
            <?php
                $select_feedback=mysqli_query($con,"SELECT * FROM `user_form`");
                if(mysqli_num_rows($select_feedback)>0)
                {
                    if($row=mysqli_fetch_assoc($select_feedback))
                    {                    
            ?>
        <div class="col-12">
          <form action="" method="post">
                <h2>Can You say your Recommends:</h2>
                <input type="text" name="name" value="<?php echo $row['name'];?>" placeholder="enter your name" class="box" required>
                <input type="email" name="email" value="<?php echo $row['email'];?>" placeholder="enter your email"  class="box" required>
                <input type="phone" name="phone" placeholder="enter your phone number" class="box" required>
                <textarea name="reply" id="reply" cols="30" rows="5" required></textarea>
                <input type="submit" value="Send" name="submit" class="btn-sub">
          </form>
        </div>
            <?php
                };
              };
            ?>
      </div>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>